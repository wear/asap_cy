module MailHelper
  def do_something_helpful(var)
    var.to_s.reverse
  end
end