class Thing
  def self.from_app; TestHelper::report_location(__FILE__); end
end