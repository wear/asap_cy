class Namespace::AlphaPluginController < ApplicationController
  def an_action
    render_class_and_action
  end  
end