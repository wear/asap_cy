map.connect 'routes/:action', :controller => "test_routing"
plugin_route 'somespace/routes/:action', :controller => "namespace/test_routing"