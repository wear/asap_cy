class Thing
  def self.from_plugin; TestHelper::report_location(__FILE__); end
end